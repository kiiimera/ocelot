﻿;==========================;		          
;						   ;			     
;       @nettlimiter       ;							     
;						   ;				     
;==========================;


#NoEnv 

#SingleInstance Force

global slowSwap := false

iconDir := A_ScriptDir "\icons"

Menu, Tray, Icon, %iconDir%\caticon.ico

Gui, +AlwaysOnTop
Gui, Font, s11 q5 cFFFFFF, Whitney
GuiControl, MoveDraw, Tab1Bg
Gui, Color, 000000

Gui, Add, Picture, x6 y10 w28 h28 gShowTab1 vTabBtn1, %iconDir%\home.png
Gui, Add, Picture, x6 y48 w28 h28 gShowTab2 vTabBtn2, %iconDir%\settings.png
Gui, Add, Picture, x6 y86 w28 h28 gShowTab3 vTabBtn3, %iconDir%\info.png

Gui, Font, s11 q5 c000000, Whitney
Gui, Add, Hotkey, x160 y77 w75 h25 vSwapbind BackgroundTrans, %Swapbind%

Gui, Add, DropDownList, x160 y47 w75 vMacroMode Hidden, 2 swap|3 swap|4 swap
GuiControlGet, MacroModeHwnd, Hwnd, MacroMode

Gui, Font, s11 cFFFFFF, Whitney
Gui, Add, Checkbox, x15 y160 w20 h25 gToggleSlowSwap vSlowSwapToggle Hidden
Gui, Add, Text, x40 y164 w100 h25 vSlowSwapLabel Hidden, slow swap

Gui, Add, Button, x160 y107 w75 h25 gUpdateHotkeys BackgroundTrans vButton1 c000000, save

Gui, Font, s11 q5 cFFFFFF
Gui, Add, Text, x205 y14 w100 h25 vDesyncLabel Hidden, desync

Gui, Font, s11 q5 c000000
Gui, Add, Edit, x270 y10 w50 h25 vCoord1X Hidden
Gui, Add, Edit, x330 y10 w50 h25 vCoord1Y Hidden

Gui, Font, s11 q5 cFFFFFF
Gui, Add, Text, x205 y44 w100 h25 vLorentzLabel Hidden, desync

Gui, Font, s11 q5 c000000
Gui, Add, Edit, x270 y40 w50 h25 vCoord2X Hidden
Gui, Add, Edit, x330 y40 w50 h25 vCoord2Y Hidden

Gui, Font, s11 q5 cFFFFFF
Gui, Add, Text, x205 y74 w100 h25 vDualityLabel Hidden, desync

Gui, Font, s11 q5 c000000
Gui, Add, Edit, x270 y70 w50 h25 vCoord3X Hidden
Gui, Add, Edit, x330 y70 w50 h25 vCoord3Y Hidden

Gui, Font, s11 q5 cFFFFFF
Gui, Add, Text, x207 y104 w100 h25 vCoord4Label Hidden, duality

Gui, Font, s11 q5 c000000
Gui, Add, Edit, x270 y100 w50 h25 vCoord4X Hidden
Gui, Add, Edit, x330 y100 w50 h25 vCoord4Y Hidden

Gui, Font, s11 q5 cFFFFFF
Gui, Add, Text, x80 y14 w100 h25 vLoopLabel Hidden, loop amount

Gui, Add, Text, x70 y74 w80 h25 vLoop3Label Hidden, 3 swap

Gui, Font, s11 q5 c000000
Gui, Add, Edit, x130 y70 w40 h25 vLoop3Count Hidden

Gui, Font, s11 q5 cFFFFFF
Gui, Add, Text, x70 y104 w80 h25 vLoop4Label Hidden, 4 swap

Gui, Font, s11 q5 c000000
Gui, Add, Edit, x130 y100 w40 h25 vLoop4Count Hidden

Gui, Font, s11 q5 cFFFFFF
Gui, Add, Text, x70 y44 w80 h25 vLoop2Label Hidden, 2 swap

Gui, Font, s11 q5 c000000
Gui, Add, Edit, x130 y40 w40 h25 vLoop2Count Hidden

Gui, Font, s11 q5 cFFFFFF
Gui, Add, Text, x80 y134 w80 h25 vCustomInputLabel Hidden, 3074UL bind

Gui, Font, s11 q5 c000000
Gui, Add, Hotkey, x70 y160 w100 h25 vCustomInput Hidden

Gui, Font, s9 c000000, Whitney
Gui, Add, Button, x270 y130 w110 h25 gOpenSpy vFindCoordsBtn Hidden, find your coords
Gui, Font, s11 c000000, Whitney

Gui, Add, Button, x270 y160 w110 h25 gSaveCoords vSaveCoordsBtn Hidden, save data

Gui, Font, s11 cFFFFFF, Whitney
Gui, Add, Button, x155 y20 w80 h25 gShowGuide vGuideBtn Hidden, guide

Gui, Font, s11 cFFFFFF, Whitney
Gui, Add, Text, x150 y70 w150 h25 vSwap2CountLabel Hidden, 2 swap uses: 0
Gui, Add, Text, x150 y100 w150 h25 vSwap3CountLabel Hidden, 3 swap uses: 0
Gui, Add, Text, x150 y130 w150 h25 vSwap4CountLabel Hidden, 4 swap uses: 0
Gui, Add, Text, x100 y170 w300 h25 vTab3Text Hidden, any issues - @nettlimiter on discord


LoadData()
UpdateStatsLabels()

Gui, Show, w400 h200, ocelot
Gosub, ShowTab1
return

ShowTab1:
	HideAll()
	GuiControl, Show, Swapbind
	GuiControl, Show, Button1
	GuiControl, Show, MacroLabel
	GuiControl, Show, MacroMode
	GuiControl, Show, SlowSwapToggle
	GuiControl, Show, SlowSwapLabel
return


ShowTab2:
	HideAll()
	GuiControl, Show, DesyncLabel
	GuiControl, Show, Coord1X
	GuiControl, Show, Coord1Y
	GuiControl, Show, LorentzLabel
	GuiControl, Show, Coord2X
	GuiControl, Show, Coord2Y
	GuiControl, Show, DualityLabel
	GuiControl, Show, Coord3X
	GuiControl, Show, Coord3Y
	GuiControl, Show, Coord4Label
	GuiControl, Show, Coord4X
	GuiControl, Show, Coord4Y
	GuiControl, Show, FindCoordsBtn
	GuiControl, Show, SaveCoordsBtn
	GuiControl, Show, Loop3Label
	GuiControl, Show, Loop3Count
	GuiControl, Show, Loop4Label
	GuiControl, Show, Loop4Count
	GuiControl, Show, LoopLabel
	GuiControl, Show, CustomInput
	GuiControl, Show, CustomInputLabel
	GuiControl, Show, Loop2Label
	GuiControl, Show, Loop2Count


return

ShowTab3:
	HideAll()
	GuiControl, Show, GuideBtn
	GuiControl, Show, Swap2CountLabel
	GuiControl, Show, Swap3CountLabel
	GuiControl, Show, Swap4CountLabel
	GuiControl, Show, Tab3Text

return

HideAll() {
	static all := ["Swapbind", "Button1", "DesyncLabel", "Coord1X", "Coord1Y"
			 , "LorentzLabel", "Coord2X", "Coord2Y"
			 , "DualityLabel", "Coord3X", "Coord3Y"
			 , "Coord4Label", "Coord4X", "Coord4Y"
			 , "Tab3Text", "FindCoordsBtn", "SaveCoordsBtn", "Loop3Label", "Loop3Count", "Loop4Label", "Loop4Count", "LoopLabel"
			 , "MacroLabel", "MacroMode", "Swap3CountLabel", "Swap4CountLabel", "Tab3Text", "CustomInput", "CustomInputLabel"
			 , "Loop2Label", "Loop2Count", "Swap2CountLabel", "GuideBtn", "SlowSwapToggle", "SlowSwapLabel"]

	for i, ctrl in all
		GuiControl, Hide, %ctrl%
}

LoadData()

return

UpdateHotkeys:
	GuiControlGet, bind1,, SwapBind
	GuiControlGet, coord1x,, Coord1X
	GuiControlGet, coord1y,, Coord1Y
	GuiControlGet, coord2x,, Coord2X
	GuiControlGet, coord2y,, Coord2Y
	GuiControlGet, coord3x,, Coord3X
	GuiControlGet, coord3y,, Coord3Y
	GuiControlGet, coord4x,, Coord4X
	GuiControlGet, coord4y,, Coord4Y
	GuiControlGet, mode,, MacroMode

	if (bind1) {
		if (bind1 != SwapBind) {
			if (SwapBind) {
				Hotkey, %SwapBind%, SwapHotkey, off
				Hotkey, %SwapBind%, 4SwapHotkey, off
			}
			SwapBind := bind1
		}

		if (mode = "3 swap") {
    		Hotkey, %SwapBind%, SwapHotkey, on
		} else if (mode = "4 swap") {
   			 Hotkey, %SwapBind%, 4SwapHotkey, on
		} else if (mode = "2 swap") {
    		Hotkey, %SwapBind%, 2SwapHotkey, on
		} 
	}

	SaveData(bind1, mode)
return

SwapHotkey:
IncrementStats("3")
#If WinActive("Destiny 2")
SendMode Input
SetWorkingDir %A_ScriptDir%

	GuiControlGet, customInput,, CustomInput

	Send {f1} 
	Sleep, 100  
	MouseMove, 515, 625

	Loop, 35  
	{
	Sleep, 35  
	Send, {Left}  
	}
	Sleep, 50  

	Send, %customInput%
	Sleep, 50

	GuiControlGet, loop3,, Loop3Count
	if (loop3 = "" or loop3 < 1)
    	loop3 := 7

	Loop, %loop3%
	{
	MouseMove, %coord1x%, %coord1y%
	Sleep, % (slowSwap ? 50 : 30)
	Click  
	Sleep, % (slowSwap ? 50 : 30)
	MouseMove, %coord2x%, %coord2y%
	Sleep, % (slowSwap ? 50 : 30)
	Click  
	Sleep, % (slowSwap ? 50 : 30)
	MouseMove, %coord4x%, %coord4y%
	Sleep, % (slowSwap ? 50 : 30)
	Click  
	Sleep, % (slowSwap ? 50 : 30)
	}

	Loop, 5
	{
	MouseMove, %coord4x%, %coord4y%
	Sleep, 50 
	Click  
	Sleep, 50 
	}

	Send {f1} 
	Sleep, 300

	Send, %customInput%
	Sleep, 200 

return

F5::reload

GuiClose:
	ExitApp


SaveCoords:
	GuiControlGet, coord1x,, Coord1X
	GuiControlGet, coord1y,, Coord1Y
	GuiControlGet, coord2x,, Coord2X
	GuiControlGet, coord2y,, Coord2Y
	GuiControlGet, coord3x,, Coord3X
	GuiControlGet, coord3y,, Coord3Y
	GuiControlGet, coord4x,, Coord4X
	GuiControlGet, coord4y,, Coord4Y
	GuiControlGet, loop3,, Loop3Count
	GuiControlGet, loop4,, Loop4Count
	GuiControlGet, loop2,, Loop2Count
	GuiControlGet, customInput,, CustomInput

	dataFile := A_ScriptDir "\data.txt"
	FileDelete, %dataFile%
	FileAppend, %coord1x%`n%coord1y%`n%coord2x%`n%coord2y%`n%coord3x%`n%coord3y%`n%coord4x%`n%coord4y%`n%loop3%`n%loop4%`n%customInput%`n%loop2%, %dataFile%

	ShowSavedOverlay()
return

ShowSavedOverlay() {
	Gui, Overlay:New
	Gui, Overlay:+AlwaysOnTop -Caption +ToolWindow +LastFound
	Gui, Overlay:Color, EEFFEE
	Gui, Overlay:Font, s10 Bold, Segoe UI
	Gui, Overlay:Add, Text, center w160 h18, data saved

	WinGetPos, x, y, w, h, A
	x += (w // 2) - 80
	y += (h // 2) - 15

	Gui, Overlay:Show, x%x% y%y% NoActivate, Overlay
	SetTimer, RemoveOverlay, -1500
}

RemoveOverlay:
	Gui, Overlay:Destroy
return


SaveData(bind1, mode) {
	IniWrite, %bind1%, %A_ScriptDir%\binds.ini, BindSettings, SwapBind
	IniWrite, %mode%, %A_ScriptDir%\binds.ini, BindSettings, MacroMode
}

UpdateStatsLabels() {
	global
	FileRead, stats, %A_ScriptDir%\stats.txt
	StringSplit, statsArray, stats, `n
	swap3 := statsArray1
	swap4 := statsArray2
	swap2 := statsArray3
	if (swap3 = "")
		swap3 := 0
	if (swap4 = "")
		swap4 := 0
	if (swap2 = "")
		swap2 := 0
	GuiControl,, Swap3CountLabel, 3 Swap Uses: %swap3%
	GuiControl,, Swap4CountLabel, 4 Swap Uses: %swap4%
	GuiControl,, Swap2CountLabel, 2 Swap Uses: %swap2%
}

IncrementStats(which) {
	statsFile := A_ScriptDir "\stats.txt"
	if !FileExist(statsFile)
		FileAppend, 0`n0, %statsFile%
	FileRead, stats, %statsFile%
	StringSplit, statsArray, stats, `n

	swap3 := statsArray1
	swap4 := statsArray2
	swap2 := statsArray3

	if (which = "3")
		swap3++
	else if (which = "4")
		swap4++
	else if (which = "2")
		swap2++

	FileDelete, %statsFile%
	FileAppend, %swap3%`n%swap4%`n%swap2%, %statsFile%

	UpdateStatsLabels()
}

OpenSpy:
{
	if WinExist("Mouse Coords") {
		WinActivate  
		return
	}

	Gui, Coords:New
	Gui, Coords:+AlwaysOnTop +MinimizeBox +SysMenu
	Gui, Coords:Font, s10, Consolas
	Gui, Coords:Add, Text, vCoordText w146 h30 center, X: ---  Y: ---
	Gui, Coords:Show, w170 h50, !

	SetTimer, UpdateCoords, 100
}
return

UpdateCoords:
{
	MouseGetPos, x, y
	GuiControl, Coords:, CoordText, X: %x%    Y: %y%
}
return

LoadData() {
	IniRead, bind1, %A_ScriptDir%\binds.ini, BindSettings, SwapBind
	IniRead, mode, %A_ScriptDir%\binds.ini, BindSettings, MacroMode
	GuiControl,, SwapBind, %bind1%
	
		if (mode = "3 swap") {
			GuiControl,, MacroMode, |2 swap|3 swap|4 swap
		}
		else if (mode = "4 swap") {
			GuiControl,, MacroMode, |2 swap|3 swap|4 swap
		}
		else if (mode = "2 swap") {
			GuiControl,, MacroMode, |2 swap|3 swap|4 swap
		}
		else {
			GuiControl,, MacroMode, |2 swap|3 swap|4 swap
			mode := "3 swap"
		}


	dataFile := A_ScriptDir "\data.txt"
	if FileExist(dataFile) {
		FileRead, data, %dataFile%
		StringSplit, coordArray, data, `n
		GuiControl,, Coord1X, %coordArray1%
		GuiControl,, Coord1Y, %coordArray2%
		GuiControl,, Coord2X, %coordArray3%
		GuiControl,, Coord2Y, %coordArray4%
		GuiControl,, Coord3X, %coordArray5%
		GuiControl,, Coord3Y, %coordArray6%
		GuiControl,, Coord4X, %coordArray7%
		GuiControl,, Coord4Y, %coordArray8%
		GuiControl,, Loop3Count, %coordArray9%
		GuiControl,, Loop4Count, %coordArray10%
		GuiControl,, CustomInput, %coordArray11%
		GuiControl,, Loop2Count, %coordArray12%
	}
}


GuiControlGet, bind1,, SwapBind
GuiControlGet, mode,, MacroMode
if (bind1) {
	if (mode = "3 swap") {
		Hotkey, %bind1%, SwapHotkey, on
	} else if (mode = "4 swap") {
		Hotkey, %bind1%, 4SwapHotkey, on
	} else if (mode = "2 swap") {
		Hotkey, %bind1%, 2SwapHotkey, on
	}
}

4SwapHotkey:
IncrementStats("4")
#If WinActive("Destiny 2")
SendMode Input
SetWorkingDir %A_ScriptDir%

GuiControlGet, customInput,, CustomInput

Send {f1} 
Sleep, 100  
MouseMove, 515, 625

Loop, 30  
{
	Sleep, 25  
	Send, {Left}  
}
Sleep, 130 

Send, %customInput%
Sleep, 50 

GuiControlGet, loop4,, Loop4Count
if (loop4 = "" or loop4 < 1)
    loop4 := 4

Loop, %loop4%
{
	MouseMove, %coord1x%, %coord1y% 
	Sleep, % (slowSwap ? 50 : 30)
	Click  
	Sleep, % (slowSwap ? 50 : 30) 
	MouseMove, %coord2x%, %coord2y%  
	Sleep, % (slowSwap ? 50 : 30)  
	Click  
	Sleep, % (slowSwap ? 50 : 30)
	MouseMove, %coord3x%, %coord3y% 
	Sleep, % (slowSwap ? 50 : 30) 
	Click  
	Sleep, % (slowSwap ? 50 : 30) 
	MouseMove, %coord4x%, %coord4y%  
	Sleep, % (slowSwap ? 50 : 30)  
	Click  
	Sleep, % (slowSwap ? 50 : 30)  
} 

Loop, 5  
{
	MouseMove, %coord4x%, %coord4y%  
	Sleep, 35
	Click  
	Sleep, 35
}

Send, %customInput%
Sleep, 50 

Send {f1}  
Sleep, 200
return

2SwapHotkey:
IncrementStats("2")
#If WinActive("Destiny 2")
SendMode Input
SetWorkingDir %A_ScriptDir%

	GuiControlGet, customInput,, CustomInput

	Send {f1} 
	Sleep, 100  
	MouseMove, 515, 625

	Loop, 35  
	{
	Sleep, 35  
	Send, {Left}  
	}
	Sleep, 50  

	Send, %customInput%
	Sleep, 50

	GuiControlGet, loop2,, Loop2Count
	if (loop2 = "" or loop2 < 1)
    	loop2 := 7

	Loop, %loop2%
	{
	MouseMove, %coord1x%, %coord1y%
	Sleep, % (slowSwap ? 50 : 30) 
	Click  
	Sleep, % (slowSwap ? 50 : 30)
	MouseMove, %coord4x%, %coord4y%
	Sleep, % (slowSwap ? 50 : 30)
	Click  
	Sleep, % (slowSwap ? 50 : 30)
	}

	Loop, 4
	{
	MouseMove, %coord4x%, %coord4y%
	Sleep, 50 
	Click  
	Sleep, 50 
	}

	Send {f1} 
	Sleep, 300

	Send, %customInput%
	Sleep, 200 

return

ToggleSlowSwap:
	GuiControlGet, isChecked,, SlowSwapToggle
	slowSwap := (isChecked = 1)
return

ShowGuide:
{
	if WinExist("Swap Guide") {
		WinActivate
		return
	}
	Gui, Guide:New
	Gui, Guide:+AlwaysOnTop +MinimizeBox +SysMenu
	Gui, Guide:Font, s10, Segoe UI
	Gui, Guide:Add, Text, w380 h280 vGuideText Wrap,
(
	omg would you like me to hold your hand :3`n`nuse the find coords button to like find your coords`nbut like make sure ur focused on destiny and not tabbed on somethn else`n`nenter your coords as required!`n2 swap uses desync 1, 3 swap uses desync 1 and 2`ni bet you will never guess what 4 swap uses!!!`n`nset your loop amounts!`nthis is just how many times the set loadouts will be cycled`nfor example, i use 8, 6 and 4 loops for 2, 3 and 4 swap`n`nby default, the sleep time between swaps is 60ms`nwith slow swap enabled, it increases to 100ms if preferred
)
	Gui, Guide:Add, Button, gCloseGuide x150 y290 w80 h25, Close
	Gui, Guide:Show, w400 h320, ocelot swap guide
}
return

CloseGuide:
	Gui, Guide:Destroy
return

OnExit, CleanupTempFiles
return

CleanupTempFiles:
FileRemoveDir, %tempDir%, 1 
ExitApp
return