﻿;==========================;		          
;						   ;			     
;       @nettlimiter       ;							     
;						   ;				     
;==========================;

#NoEnv 
#MaxThreadsperHotkey 4
#SingleInstance Force

if (!A_IsAdmin){ 
    Run *RunAs "%A_AhkPath%" "%A_ScriptFullPath%"
}

Menu, Tray, Icon, %A_ScriptDir%\images\cute-cartoon-hamburger-file-free-png.png

auto_buffer := 0
sound_cue := 0

toggle27k := false
toggle3074 := false
togglePause := false

mainGUI:

    Gui, +AlwaysOnTop
    Gui, Font, s11 q5 cc2c5c9, Whitney
    Gui, Color, 000000

    Gui Add, Text, x10 y10 w150 h25 +0x200, 27k:
    Gui Add, Hotkey, x220 y10 w75 h25 v27Kbind, %27Kbind%
    Gui Add, Text, x10 y40 w150 h25 +0x200, 3074:
    Gui Add, Hotkey, x220 y40 w75 h25 v3074bind, %3074bind%

    Gui Add, Text, x10 y100 w75 h25 +0x200, Auto-Buffer:
    Gui Add, CheckBox, x220 y100 w75 h25 vautoBuffer gCheck
	
	Gui Add, Text, x10 y130 w75 +0x200, Sound-Cues:
	Gui Add, CheckBox, x220 y130 w75 h25 vsoundCues gCheckSound
	
    Gui Add, Text, x10 y70 w150 h25 +0x200, Pause:
    Gui Add, Hotkey, x220 y70 w75 h25 vpauseBind, %pauseBind%

    Gui Add, Text, x100 y10 w30 h25 +0x200 v27kStatus, OFF
	Gui Add, Text, x140 y10 w30 h25 +0x200 v27UTime, 0
	Gui Add, Text, x180 y10 w30 h25 +0x200 v27DTime, 0
	
    Gui Add, Text, x100 y40 w30 h25 +0x200 v3074Status, OFF
	Gui Add, Text, x140 y40 w30 h25 +0x200 v3074UTime, 0
	Gui Add, Text, x180 y40 w30 h25 +0x200 v3074DTime, 0
	
    Gui Add, Text, x100 y70 w30 h25 +0x200 vpauseStatus, OFF
	
    Gui Add, Button, x100 y160 w100 h20 gUpdateHotkeys, Save
    Gui, Show, w300 h190, Burger

return

27kHotkey:
	toggle27k := !toggle27k
	if (auto_buffer) {
		if (toggle27k) {
			if (sound_cue){
				SoundBeep, 523
				SoundBeep, 750
			}
		}
		loop {
			if (toggle27k){
				Random, randUnlimit, 350, 500
				sleep, %randUnlimit%
				GuiControl,, 27kStatus, ON
				enable27k()

				Random, randLimit, 5000, 7000
				GuiControl,, 27UTime, %randLimit%
				GuiControl,, 27DTime, %randUnlimit%
				sleep, %randLimit%
				GuiControl,, 27kStatus, OFF
				disable27k()
			} else {
				if (sound_cue){
					SoundBeep, 750
					SoundBeep, 523
				}
				GuiControl,, 27UTime, 0
				GuiControl,, 27DTime, 0
				GuiControl,, 27kStatus, OFF
				break
			}
		}
	} else {	
		if (toggle27k) {
			GuiControl,, 27kStatus, ON
			enable27k()
			if (sound_cue){
				SoundBeep, 523
				SoundBeep, 750
			}
		}
		else {
			GuiControl,, 27kStatus, OFF
			disable27k()
			if (sound_cue){
				SoundBeep, 750
				SoundBeep, 523
			}
		}
	}
return

3074Hotkey:
	toggle3074 := !toggle3074
	if (auto_buffer) {
		if (toggle3074) {
			if (sound_cue) {
				SoundBeep, 523
				SoundBeep, 750
			}
		}
		loop {
			if (toggle3074){
				Random, randUnlimit, 350, 500
				sleep, %randUnlimit%
				GuiControl,, 3074Status, ON
				enable3074()

				Random, randLimit, 5000, 7000
				GuiControl,, 3074UTime, %randLimit%
				GuiControl,, 3074DTime, %randUnlimit%
				sleep, %randLimit%
				GuiControl,, 3074Status, OFF
				disable3074()
			} else {
				if (sound_cue){
					SoundBeep, 750
					SoundBeep, 523
				}
				GuiControl,, 3074UTime, 0
				GuiControl,, 3074DTime, 0
				GuiControl,, 3074Status, OFF
				break
			}
		}
	} else {
		if (toggle3074) {
			GuiControl,, 3074Status, ON
			enable3074()
			if (sound_cue){
				SoundBeep, 523
				SoundBeep, 750
			}
		}
		else {
			GuiControl,, 3074Status, OFF
			disable3074()
			if (sound_cue){
				SoundBeep, 750
				SoundBeep, 523
			}
		}
	}
return

PauseHotkey:
	togglePause := !togglePause
    if (togglePause) {
        GuiControl,, pauseStatus, ON
	    Process_Suspend("destiny2.exe")
		if (sound_cue){
			SoundBeep, 523
			SoundBeep, 750
		}
	}
    else {
        GuiControl,, pauseStatus, OFF
	    Process_Resume("destiny2.exe")
		if (sound_cue){
			SoundBeep, 750
			SoundBeep, 523
		}
	}
return

UpdateHotkeys:
    GuiControlGet, bind1,, 27kBind

    if (bind1){
        if(bind1 != 27kBind) {
            if (27kBind){
                Hotkey, %27kBind%, 27kHotkey, off
            }
            27kBind := bind1  
            Hotkey, %27kBind%, 27kHotkey, on
        }
    }

    GuiControlGet, bind3,, 3074Bind

    if (bind3){
        if(bind3 != 3074Bind) {
            if(3074bind){
                Hotkey, %3074Bind%, 3074Hotkey, off
            }
            3074Bind := bind3  
            Hotkey, %3074Bind%, 3074Hotkey, on
        }
    }

    GuiControlGet, bind4,, pauseBind

    if (bind4){
        if(bind4 != pauseBind) {
            if(pauseBind){
                Hotkey, %pauseBind%, pauseHotkey, off
            }
            pauseBind := bind4  
            Hotkey, %pauseBind%, pauseHotkey, on
        }
    }
return

Check:
	GuiControlGet, autoBuffer
	if (autoBuffer) {
		auto_buffer := 1
	} else {
		auto_buffer := 0
	}
	
	
return

CheckSound:
	GuiControlGet, soundCues
	if (soundCues) {
		sound_cue := 1
	} else {
		sound_cue := 0
	}
return

enable27k(){
    
    run netsh advfirewall firewall add rule dir=out action=block name="d2limit-27k-tcp-out" profile=any remoteport=27015-27200 protocol=tcp interfacetype=any,,hide
    run netsh advfirewall firewall add rule dir=out action=block name="d2limit-27k-udp-out" profile=any remoteport=27015-27200 protocol=udp interfacetype=any,,hide
    run netsh advfirewall firewall add rule dir=in action=block name="d2limit-27k-tcp-in" profile=any remoteport=27015-27200 protocol=tcp interfacetype=any,,hide
    run netsh advfirewall firewall add rule dir=in action=block name="d2limit-27k-udp-in" profile=any remoteport=27015-27200 protocol=udp interfacetype=any,,hide
}

disable27k(){
    run netsh advfirewall firewall delete rule name="d2limit-27k-tcp-out",,hide
    run netsh advfirewall firewall delete rule name="d2limit-27k-udp-out",,hide
    run netsh advfirewall firewall delete rule name="d2limit-27k-tcp-in",,hide
    run netsh advfirewall firewall delete rule name="d2limit-27k-udp-in",,hide
}

enable30k(){
    ;run netsh advfirewall firewall add rule dir=out action=block name="d2limit-30k-tcp-out" profile=any remoteport=30000-30009 protocol=tcp interfacetype=any,,hide
    ;run netsh advfirewall firewall add rule dir=out action=block name="d2limit-30k-udp-out" profile=any remoteport=30000-30009 protocol=udp interfacetype=any,,hide
    run netsh advfirewall firewall add rule dir=in action=block name="d2limit-30k-tcp-in" profile=any remoteport=30000-30009 protocol=tcp interfacetype=any,,hide
    run netsh advfirewall firewall add rule dir=in action=block name="d2limit-30k-udp-in" profile=any remoteport=30000-30009 protocol=udp interfacetype=any,,hide

}

disable30k(){
    ;run netsh advfirewall firewall delete rule name="d2limit-3074-tcp-out",,hide
    ;run netsh advfirewall firewall delete rule name="d2limit-3074-udp-out",,hide
    run netsh advfirewall firewall delete rule name="d2limit-30k-tcp-in",,hide
    run netsh advfirewall firewall delete rule name="d2limit-30k-udp-in",,hide
}

enable3074(){
    run netsh advfirewall firewall add rule dir=out action=block name="d2limit-3074-tcp-out" profile=any remoteport=3074 protocol=tcp interfacetype=any,,hide
    run netsh advfirewall firewall add rule dir=out action=block name="d2limit-3074-udp-out" profile=any remoteport=3074 protocol=udp interfacetype=any,,hide
    run netsh advfirewall firewall add rule dir=in action=block name="d2limit-3074-tcp-in" profile=any remoteport=3074 protocol=tcp interfacetype=any,,hide
    run netsh advfirewall firewall add rule dir=in action=block name="d2limit-3074-udp-in" profile=any remoteport=3074 protocol=udp interfacetype=any,,hide
}

disable3074(){
    run netsh advfirewall firewall delete rule name="d2limit-3074-tcp-out",,hide
    run netsh advfirewall firewall delete rule name="d2limit-3074-udp-out",,hide
    run netsh advfirewall firewall delete rule name="d2limit-3074-tcp-in",,hide
    run netsh advfirewall firewall delete rule name="d2limit-3074-udp-in",,hide
}

enable3074UL() {
	run netsh advfirewall firewall add rule dir=out action=block name="d2limit-3074-tcp-out" profile=any remoteport=3074 protocol=tcp interfacetype=any,,hide
    run netsh advfirewall firewall add rule dir=out action=block name="d2limit-3074-udp-out" profile=any remoteport=3074 protocol=udp interfacetype=any,,hide

}

disable3074UL() {
	run netsh advfirewall firewall delete rule name="d2limit-3074-tcp-out",,hide
    run netsh advfirewall firewall delete rule name="d2limit-3074-udp-out",,hide
}

Process_Suspend(PID_or_Name){
    PID := (InStr(PID_or_Name,".")) ? ProcExist(PID_or_Name) : PID_or_Name
    h:=DllCall("OpenProcess", "uInt", 0x1F0FFF, "Int", 0, "Int", pid)
    If !h   
        Return -1
    DllCall("ntdll.dll\NtSuspendProcess", "Int", h)
    DllCall("CloseHandle", "Int", h)
	Return
	}
 
Process_Resume(PID_or_Name){
    PID := (InStr(PID_or_Name,".")) ? ProcExist(PID_or_Name) : PID_or_Name
    h:=DllCall("OpenProcess", "uInt", 0x1F0FFF, "Int", 0, "Int", pid)
    If !h   
        Return -1
    DllCall("ntdll.dll\NtResumeProcess", "Int", h)
    DllCall("CloseHandle", "Int", h)
	}

ProcExist(PID_or_Name=""){
    Process, Exist, % (PID_or_Name="") ? DllCall("GetCurrentProcessID") : PID_or_Name
    Return Errorlevel
}
return

OnMessage(0x112, "WM_SYSCOMMAND")
WM_SYSCOMMAND(wParam, lParam) {
    if (wParam = 0xF020) { ; minimize
        Gui, Hide
        return 0
    }
}

Menu, Tray, NoStandard
Menu, Tray, Add, Show Burger GUI, ShowGUI
Menu, Tray, Add, Exit, ExitApp
Menu, Tray, Default, Show Burger GUI

ShowGUI:
    Gui, Show
return
	

F5::reload

ExitApp:
	disable27k()
    disable30k()
    disable3074()
ExitApp
return

;================================================;
;						   						 ;	     
;       limiter code originally by goose		 ;
;						  						 ;				     
;================================================;